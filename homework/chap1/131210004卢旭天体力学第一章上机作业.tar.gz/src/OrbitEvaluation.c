//

#include <stdio.h>
#include <math.h>
#include "NumericalRecipes.h"
#include "OrbitalEle_CoorVol_Trans.h"
#include "Constants.h"

/**
 * Derivatives of x,y,z,vx,vy,vz with respect to time t
 * @param t time
 * @param y 6 components of coordinates and volocities(x,y,z,vx,vy,vz)
 * @return derivatives of x,y,z,vx,vy,vz with respect to time t
 */
double dx(double t, double *y)
{
    return y[3];
}
double dy(double t, double *y)
{
    return y[4];
}
double dz(double t, double *y)
{
    return y[5];
}
double dvx(double t, double *y)
{
    return - mu * y[0] / pow(y[0] * y[0] + y[1] * y[1] + y[2] * y[2], 1.5);
}
double dvy(double t, double *y)
{
    return - mu * y[1] / pow(y[0] * y[0] + y[1] * y[1] + y[2] * y[2], 1.5);
}
double dvz(double t, double *y)
{
    return - mu * y[2] / pow(y[0] * y[0] + y[1] * y[1] + y[2] * y[2], 1.5);
}

int main(int argc, char const *argv[])
{
    mu = G * (MSun + MEarth);
    OrbElem orbEarth = {1.00000011, 0.01671022, 0.00005, -11.26064 / 180 * pi, 102.94719 / 180 * pi, 1.0};
    OrbElem orb1 = orbEarth;
    CoorVol coor = OrbElem2CoorVol(orb1);

    // some parameters
    double step = 86400;
    double downlim = 0;
    double uplim = 63115200.0;
    int numoffuncs = 6;
    double TOL = 1e-5;
    double hmax = 864000;
    double hmin = 86.4;

    double initialstate[6] = {coor.x, coor.y, coor.z, coor.vx, coor.vy, coor.vz};
    double (*f[6])(double, double*) = {dx, dy, dz, dvx, dvy, dvz};
    double **result = SODERKF(f, initialstate, downlim, uplim, numoffuncs, step, TOL, hmax, hmin, 13);

    int temp = (uplim - downlim) / hmin + 1;
    for(int i = 0; i < temp; i+=1)
    {
        if(result[i][0] == 0)
        {
            break;
        }
        double resx = result[i][0];
        double resy = result[i][1];
        double resz = result[i][2];
        double r = sqrt(resx * resx + resy * resy + resz * resz);
        printf("r:%f x:%f y:%f z:%f vx:%f vy:%f vz:%f\n", r, resx, resy, resz, result[i][3], result[i][4], result[i][5]);
    }
    return 0;
}
